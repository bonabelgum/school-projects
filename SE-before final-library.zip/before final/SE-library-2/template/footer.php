<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      <!--ul>
        <li><a href="https://github.com/omkar2403/inout/" target="_blank">In Out Management System</a></li>
        <li><a href="https://www.koha-community.org/" target="_blank">Powered By KOHA Community</a></li>
      </ul-->
    </nav>
    <!--div class="copyright float-right">©
      <script>document.write(new Date().getFullYear())</script>, made with 
      <i class="material-icons" style="color:red;">favorite</i> by
      <a href="https://omkar2403.github.io/its_me/" target="_blank">Omkar Kakeru</a> for a better web.
    </div-->
  </div>
</footer>               
</div>          
</div>

<!-- Core Js -->
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<!-- Main Js -->
<script src="assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
<!-- Scroll Bar -->
<script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script> 
<!-- Plugin for the momentJs  -->
<script src="assets/js/plugins/moment.min.js"></script> 
<!--  Plugin for Sweet Alert -->
<script src="assets/js/plugins/sweetalert2.js"></script> 
<!-- Forms Validations Plugin -->
<script src="assets/js/plugins/jquery.validate.min.js"></script> 
<!--  Plugin for the Wizard -->
<script src="assets/js/plugins/jquery.bootstrap-wizard.js"></script> 
<!--  Plugin for Select -->
<script src="assets/js/plugins/bootstrap-selectpicker.js"></script> 
<!--  Plugin for the DateTimePicker -->
<script src="assets/js/plugins/bootstrap-datetimepicker.min.js"></script> 
<!--  Plugin for Tags -->
<script src="assets/js/plugins/bootstrap-tagsinput.js"></script> 
<!-- Plugin for Fileupload -->
<script src="assets/js/plugins/jasny-bootstrap.min.js"></script> 
<!--  Full Calendar Plugin -->
<script src="assets/js/plugins/fullcalendar.min.js"></script> 
<!-- Vector Map plugin -->
<script src="assets/js/plugins/jquery-jvectormap.js"></script> 
<!--  Plugin for the Sliders -->
<script src="assets/js/plugins/nouislider.min.js"></script> 
<!-- Core -->
<script src="assets/js/core/core.js"></script>
<!-- Library for adding dinamically elements -->
<script src="assets/js/plugins/arrive.min.js"></script>
<!-- Chartist JS -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!-- Control Center for Material Dashboard -->
<script src="assets/js/material-dashboard.min.js?v=2.0.2" type="text/javascript"></script>

<!-- DATE TIME PICKER AND SLIDERS -->
<script>
  $(document).ready(function(){
    // initialise Datetimepicker and Sliders
    md.initFormExtendedDatetimepickers();
    if($('.slider').length != 0){
      md.initSliders();
    }
  });
</script>

<?php if (isset($table) && $table): ?>
<script>
$(document).ready(function () {

  // ---------- DATATABLES (EXPORTABLE TABLES) ----------
  if ($('#datatables').length) {
    $('#datatables').DataTable({
      ordering: true,
      orderCellsTop: true,
      lengthMenu: [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
      ],
      dom: 'Bfrtip',
      buttons: [
        {
          extend: 'copyHtml5',
          messageTop: window.printMsg || '',
          exportOptions: { columns: ':visible' }
        },
        {
          extend: 'excelHtml5',
          messageTop: window.printMsg || '',
          exportOptions: { columns: ':visible' }
        },
        {
          extend: 'pdfHtml5',
          messageTop: window.printMsg || '',
          exportOptions: { columns: ':visible' }
        },
        'colvis'
      ],
      responsive: true,
      language: {
        search: "_INPUT_",
        searchPlaceholder: "Search records"
      },
      initComplete: function () {
        this.api().columns().every(function () {
          const column = this;
          const select = $('<select><option value="">Show All</option></select>')
            .appendTo($(column.footer()).empty())
            .on('change', function () {
              const val = $.fn.dataTable.util.escapeRegex($(this).val());
              column.search(val ? '^' + val + '$' : '', true, false).draw();
            });

          column.data().unique().sort().each(function (d) {
            select.append('<option value="' + d + '">' + d + '</option>');
          });
        });
      }
    });
  }

});
</script>
<?php endif; ?>


<script>
document.querySelectorAll(".sortable-table:not(.datatable)").forEach(table => {
  const headers = table.querySelectorAll("th");
  const tbody = table.querySelector("tbody");

  const rowsPerPage = 50;
  const maxPageButtons = 10;

  let currentPage = 1;
  let rows = Array.from(tbody.querySelectorAll("tr"));

  /* ---------- PAGINATION WRAPPER ---------- */
  const paginationWrapper = document.createElement("div");
  paginationWrapper.className = "table-pagination-wrapper";

  const info = document.createElement("div");
  info.className = "table-pagination-info";

  const pagination = document.createElement("div");
  pagination.className = "table-pagination";

  paginationWrapper.appendChild(info);
  paginationWrapper.appendChild(pagination);
  table.parentNode.appendChild(paginationWrapper);

  function renderTable() {
    tbody.innerHTML = "";
    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;

    rows.slice(start, end).forEach(row => tbody.appendChild(row));

    info.innerText = `Showing ${start + 1}–${Math.min(end, rows.length)} of ${rows.length}`;
    renderPagination();
  }

  function renderPagination() {
    pagination.innerHTML = "";
    const pageCount = Math.ceil(rows.length / rowsPerPage);

    const rangeStart =
      Math.floor((currentPage - 1) / maxPageButtons) * maxPageButtons + 1;
    const rangeEnd = Math.min(rangeStart + maxPageButtons - 1, pageCount);

    /* PREV */
    const prevBtn = document.createElement("button");
    prevBtn.innerHTML = "◀";
    prevBtn.disabled = currentPage === 1;
    prevBtn.onclick = () => {
      if (currentPage > 1) {
        currentPage--;
        renderTable();
      }
    };
    pagination.appendChild(prevBtn);

    /* PAGE NUMBERS */
    for (let i = rangeStart; i <= rangeEnd; i++) {
      const btn = document.createElement("button");
      btn.innerText = i;
      btn.className = i === currentPage ? "active" : "";
      btn.onclick = () => {
        currentPage = i;
        renderTable();
      };
      pagination.appendChild(btn);
    }

    /* NEXT */
    const nextBtn = document.createElement("button");
    nextBtn.innerHTML = "▶";
    nextBtn.disabled = currentPage === pageCount;
    nextBtn.onclick = () => {
      if (currentPage < pageCount) {
        currentPage++;
        renderTable();
      }
    };
    pagination.appendChild(nextBtn);
  }

  /* ---------- SORTING ---------- */
  headers.forEach((header, columnIndex) => {
    let asc = true;
    const type = header.dataset.type;

    if (!type || type === "none") return;

    header.addEventListener("click", () => {
      headers.forEach(h => h.classList.remove("asc", "desc"));

      rows.sort((a, b) => {
        let aText = a.children[columnIndex].innerText.trim();
        let bText = b.children[columnIndex].innerText.trim();

        if (type === "number") return asc ? aText - bText : bText - aText;
        if (type === "date")
          return asc
            ? new Date(aText) - new Date(bText)
            : new Date(bText) - new Date(aText);
        if (type === "time")
          return asc
            ? new Date("1970-01-01 " + aText) - new Date("1970-01-01 " + bText)
            : new Date("1970-01-01 " + bText) - new Date("1970-01-01 " + aText);

        return asc
          ? aText.localeCompare(bText)
          : bText.localeCompare(aText);
      });

      header.classList.add(asc ? "asc" : "desc");
      asc = !asc;
      currentPage = 1;
      renderTable();
    });
  });

  renderTable();
});
</script>



</body>
</html>