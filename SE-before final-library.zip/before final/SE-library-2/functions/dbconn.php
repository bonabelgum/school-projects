<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "lib";
	$koha = "koha_library";
	$conn = mysqli_connect($servername, $username, $password, $db, 3307);
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error($conn));
	}

	$koha = mysqli_connect($servername, $username, $password, $koha, 3307);
	if (!$koha) {
	    die("Connection failed: " . mysqli_connect_error($koha));
	}

	function sanitize($conn, $str){
		return mysqli_real_escape_string($conn, $str);
	}
	// var_dump(function_exists('mysqli_connect'));
	date_default_timezone_set("Asia/Manila");
?>
